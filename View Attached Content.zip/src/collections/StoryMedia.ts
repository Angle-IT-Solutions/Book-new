import type { CollectionConfig } from 'payload'

export const StoryMedia: CollectionConfig = {
  slug: 'story-media',
  admin: {
    group: 'Story Reader',
    useAsTitle: 'alt',
  },
  access: {
    create: () => true,
    read: () => true,
    update: ({ req }) => Boolean(req.user),
    delete: ({ req }) => Boolean(req.user),
  },
  fields: [
    {
      name: 'alt',
      type: 'text',
      required: true,
    },
  ],
  upload: {
    mimeTypes: ['image/*', 'audio/*'],
  },
}
