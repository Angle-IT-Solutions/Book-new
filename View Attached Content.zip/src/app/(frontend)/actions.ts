'use server'

import { getPayloadClient } from '@/lib/payload'

type CreateStoryInput = {
  title: string
  image?: string | number
  audio?: string | number
}

export async function createStory(input: CreateStoryInput) {
  const title = input.title.trim()
  if (!title || title.length > 160) {
    return { error: 'Enter a title between 1 and 160 characters.' }
  }

  const payload = await getPayloadClient()
  const story = await payload.create({
    collection: 'stories',
    data: {
      title,
      slug: crypto.randomUUID(),
      ...(input.image !== undefined ? { image: input.image } : {}),
      ...(input.audio !== undefined ? { audio: input.audio } : {}),
    },
    overrideAccess: false,
  })

  return { url: `/story/${story.slug}` }
}
