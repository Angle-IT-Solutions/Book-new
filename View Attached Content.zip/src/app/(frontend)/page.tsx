'use client'

import { useEffect, useRef, useState } from 'react'
import { createStory } from './actions'

type Story = {
  title: string
  image: string
  audio: string
}

export default function HomePage() {
  const [story, setStory] = useState<Story>({
    title: 'One, Two, Buckle My Shoe',
    image: '',
    audio: '',
  })
  const [view, setView] = useState<'create' | 'read' | 'stories'>('create')
  const imageUrl = useRef('')
  const audioUrl = useRef('')
  const imageFile = useRef<File | null>(null)
  const audioFile = useRef<File | null>(null)
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState('')

  useEffect(
    () => () => {
      if (imageUrl.current) URL.revokeObjectURL(imageUrl.current)
      if (audioUrl.current) URL.revokeObjectURL(audioUrl.current)
    },
    [],
  )

  const chooseFile = (kind: 'image' | 'audio', file?: File) => {
    if (!file) return
    const urlRef = kind === 'image' ? imageUrl : audioUrl
    const fileRef = kind === 'image' ? imageFile : audioFile
    if (urlRef.current) URL.revokeObjectURL(urlRef.current)
    urlRef.current = URL.createObjectURL(file)
    fileRef.current = file
    setStory((current) => ({ ...current, [kind]: urlRef.current }))
  }

  const uploadFile = async (file: File) => {
    const body = new FormData()
    body.append('file', file)
    body.append('_payload', JSON.stringify({ alt: story.title || file.name }))
    const response = await fetch('/api/story-media', { method: 'POST', body })
    const result = (await response.json()) as {
      doc?: { id?: string | number }
      errors?: Array<{ message?: string }>
    }
    if (!response.ok || result.doc?.id === undefined) {
      throw new Error(result.errors?.[0]?.message || 'Upload failed.')
    }
    return result.doc.id
  }

  const saveStory = async () => {
    setSaving(true)
    setSaveError('')
    try {
      const [image, audio] = await Promise.all([
        imageFile.current ? uploadFile(imageFile.current) : undefined,
        audioFile.current ? uploadFile(audioFile.current) : undefined,
      ])
      const result = await createStory({ title: story.title, image, audio })
      if (!result.url) throw new Error(result.error || 'The story could not be saved.')
      try {
        await navigator.clipboard.writeText(`${window.location.origin}${result.url}`)
      } catch {
        // The permanent page still opens when clipboard permission is unavailable.
      }
      window.location.href = result.url
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'The story could not be saved.')
      setSaving(false)
    }
  }

  return (
    <main className="min-h-dvh bg-[#fff8ee] text-[#333]">
      <header className="flex min-h-[66.5px] items-center justify-between gap-4 bg-[#f7931e] px-6 py-3.5 max-sm:flex-col max-sm:items-start">
        <h1 className="font-comic-bold text-[22px] leading-[33px] text-white">Divya Jain</h1>
        <nav className="flex flex-wrap gap-2" aria-label="Story sections">
          {[
            ['create', 'Create'],
            ['read', 'Read'],
            ['stories', 'My Stories'],
          ].map(([key, label]) => (
            <button
              key={key}
              className={`nav-button ${view === key ? 'bg-white text-[#f7931e]' : 'text-white'}`}
              onClick={() => setView(key as typeof view)}
            >
              {label}
            </button>
          ))}
        </nav>
      </header>

      <div className="mx-auto flex w-full max-w-[1000px] flex-col gap-4 p-6 max-sm:p-4">
        <aside className="rounded-lg border border-[#f5d77a] bg-[#fff3cd] px-3 py-[8.5px] font-comic-regular text-[13px] leading-[19.5px]">
          Shared mode: saved stories and their media can be opened by anyone with the permanent
          link.
        </aside>

        {view === 'create' && (
          <section className="rounded-2xl bg-white p-6 shadow-[0_4px_10px_rgba(0,0,0,0.06)]">
            <h2 className="mb-4 font-comic-regular text-2xl leading-9 text-[#f7931e]">
              Create your story page
            </h2>

            <div className="space-y-4">
              <label className="field">
                <span>Title</span>
                <input
                  value={story.title}
                  onChange={(event) =>
                    setStory((current) => ({
                      ...current,
                      title: event.target.value,
                    }))
                  }
                />
              </label>

              <label className="field file-field">
                <span>Background image</span>
                <span className="file-control" aria-hidden="true" />
                <input
                  className="sr-only"
                  type="file"
                  accept="image/*"
                  onChange={(event) => chooseFile('image', event.target.files?.[0])}
                />
              </label>

              <label className="field file-field">
                <span>Audio</span>
                <span className="file-control" aria-hidden="true" />
                <input
                  className="sr-only"
                  type="file"
                  accept="audio/*"
                  onChange={(event) => chooseFile('audio', event.target.files?.[0])}
                />
              </label>
            </div>

            <div className="mt-4 flex flex-wrap gap-3">
              <button className="action-button bg-[#f7931e]" onClick={() => setView('read')}>
                Preview
              </button>
              <button
                className="action-button bg-[#2a9d8f]"
                disabled={saving}
                onClick={() => void saveStory()}
              >
                {saving ? 'Saving…' : 'Save & get permanent link'}
              </button>
            </div>
            {saveError && (
              <p className="mt-3 text-sm text-red-600" role="alert">
                {saveError}
              </p>
            )}
          </section>
        )}

        {view === 'read' && (
          <section className="story-preview">
            <div
              className="preview-image"
              style={story.image ? { backgroundImage: `url("${story.image}")` } : undefined}
            />
            <div className="preview-details">
              <h2 className="font-comic-bold text-4xl leading-tight text-[#f7931e]">
                {story.title}
              </h2>
              {story.audio && (
                <audio className="mt-4 w-full max-w-lg" controls src={story.audio}>
                  <track kind="captions" />
                </audio>
              )}
            </div>
          </section>
        )}

        {view === 'stories' && (
          <section className="rounded-2xl bg-white p-6 shadow-[0_4px_10px_rgba(0,0,0,0.06)]">
            <h2 className="font-comic-regular text-2xl leading-9 text-[#f7931e]">My Stories</h2>
            <button
              className="mt-4 font-comic-regular text-left text-base hover:text-[#f7931e]"
              onClick={() => setView('read')}
            >
              {story.title}
            </button>
          </section>
        )}
      </div>

      <footer className="py-4 text-center font-comic-regular text-[13px] leading-[19.5px] text-[#999]">
        Made by Divya Jain
      </footer>
    </main>
  )
}
